#include "test_support.h"

TEST(Pipes, ChildConnectionBranches) {
    int pipes[2][2];
    ASSERT_EQ(pipe(pipes[0]), 0);
    ASSERT_EQ(pipe(pipes[1]), 0);

    EXPECT_EQ(pipe_connect_child(nullptr, 0, 2), IMC_ERROR);
    EXPECT_EQ(pipe_connect_child(pipes, 0, 0), IMC_ERROR);

    int saved_stdin = dup(STDIN_FILENO);
    int saved_stdout = dup(STDOUT_FILENO);

    int r1 = pipe_connect_child(pipes, 1, 2);
    int r2 = pipe_connect_child(pipes, 0, 2);

    dup2(saved_stdin, STDIN_FILENO);
    close(saved_stdin);
    dup2(saved_stdout, STDOUT_FILENO);
    close(saved_stdout);

    EXPECT_EQ(r1, IMC_OK);
    EXPECT_EQ(r2, IMC_OK);

    pipe_close_all(pipes, 2);
    pipe_close_all(nullptr, 2);
}
