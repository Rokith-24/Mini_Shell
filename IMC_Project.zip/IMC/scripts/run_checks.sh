#!/bin/sh
set -eu
make clean
make
make test
if command -v cppcheck >/dev/null 2>&1; then make cppcheck; else echo "cppcheck not installed; skipped"; fi
if command -v valgrind >/dev/null 2>&1; then
    printf 'exit\n' | valgrind --leak-check=full --error-exitcode=1 ./build/imc
else
    echo "valgrind not installed; skipped"
fi
