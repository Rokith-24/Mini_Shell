#!/bin/sh
set -eu
make clean
make coverage
if command -v lcov >/dev/null 2>&1; then
    lcov --capture --directory . --output-file reports/coverage.info
    genhtml reports/coverage.info --output-directory reports/coverage-html
else
    echo "lcov/genhtml not installed; gcov output is available."
fi
