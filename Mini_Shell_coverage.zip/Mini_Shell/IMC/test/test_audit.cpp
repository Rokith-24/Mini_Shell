#include "test_support.h"

TEST(Audit, RecordAndReportOperations) {
    auto f = temp_name("audit.log");
    imc_config_t config{};
    config_defaults(&config);
    (void)snprintf(config.audit_path, sizeof(config.audit_path), "%s", f.c_str());

    audit_record(&config, 1001, "echo test", 0);
    audit_record(&config, 1002, "false", 1);

    testing::internal::CaptureStdout();
    audit_report(&config);
    auto out = testing::internal::GetCapturedStdout();
    EXPECT_NE(out.find("SUCCESS"), std::string::npos);
    EXPECT_NE(out.find("FAILED"), std::string::npos);
    EXPECT_NE(out.find("total=2 success=1 failed=1"), std::string::npos);

    std::remove(f.c_str());
}

TEST(Audit, NullAndMissingHandling) {
    audit_record(nullptr, 1, "c", 0);
    imc_config_t config{};
    config_defaults(&config);
    audit_record(&config, 1, nullptr, 0);

    (void)snprintf(config.audit_path, sizeof(config.audit_path), "/tmp/nonexistent_audit_123");
    testing::internal::CaptureStdout();
    audit_report(&config);
    auto out = testing::internal::GetCapturedStdout();
    EXPECT_NE(out.find("No audit records found"), std::string::npos);
    audit_report(nullptr);
}
