# Infrastructure Management Console (IMC)

A modular Bash-like Linux shell and lightweight Infrastructure Management Console written in C11.

## Target environment
- Red Hat Enterprise Linux 8/9 (primary)
- GCC with POSIX/Linux headers
- `make`
- Optional: Cppcheck, Valgrind, Helgrind, gcov, lcov, genhtml

This implementation uses POSIX process APIs (`fork`, `execvp`, `waitpid`, `pipe`, `dup2`, `sigaction`) and is therefore designed for Linux. It is not a native Windows shell.

## Build

```sh
make
```

## Run

```sh
make run
```

or:

```sh
./build/imc
```

## Commands

### Shell
```text
help
pwd
cd [directory]
history [count]
jobs
fg JOB_ID
bg JOB_ID
kill-job JOB_ID
exit
```

### Shell operators
```sh
ls -l
sleep 30 &
ls | wc -l
cat < input.txt
ls > output.txt
echo hello >> output.txt
pwd ; date
echo "$HOME"
```

### Infrastructure
```text
service-status [process-name]
log-search KEYWORD [FILE]
log-summary [FILE]
healthcheck
system-summary
cleanup
audit-report
```

`service-status` provides process-oriented information. Use `systemctl status SERVICE` as an external command for systemd unit status.

## Build and quality targets

```sh
make
make test
make cppcheck
make coverage
make valgrind
make helgrind
make clean
```

The optional tools are not installed automatically. Run `scripts/run_checks.sh` to execute available checks.

## Configuration

Edit `config/imc.conf`:

```ini
history_path=data/history.txt
audit_path=logs/audit.log
log_path=logs/imc.log
history_size=500
show_timestamp=false
```

## Data files
- `data/history.txt`: timestamped command history.
- `logs/audit.log`: timestamp, PID, command and status.
- `logs/imc.log`: runtime diagnostics.

## Project structure

```text
IMC/
├── src/
│   ├── shell/             Shell core
│   ├── parser/            Command parser
│   ├── process/           Process manager
│   ├── jobs/              Job manager
│   ├── pipes/             Pipeline handling
│   ├── redirection/       Input/output redirection
│   ├── history/            Command history
│   ├── audit/              Audit records and reports
│   ├── logger/             Runtime logger
│   ├── builtins/           Built-in commands
│   ├── monitoring/         Infrastructure monitoring
│   └── config/             Configuration loader
├── include/             Shared public declarations
├── tests/               Automated C tests
├── data/                 Persistent command history
├── logs/                 Audit and runtime logs
├── reports/              Generated reports and coverage
├── config/               Runtime configuration
├── scripts/              Quality-check scripts
├── docs/                 Architecture and test plan
├── build/                Object files and executable
├── Makefile
└── README.md
```

## Known limitations / engineering notes

- This is a complete starter implementation of the stated shell scope, not a security-hardened replacement for Bash.
- Job control supports process groups and basic `jobs`/`fg`/`bg` operations. Complex terminal-control edge cases and pipelines with multiple stopped children require further hardening.
- The parser supports bounded commands, quotes, environment-variable expansion, pipelines, redirection, background execution and semicolon-separated commands. It does not implement shell globbing, command substitution, here-documents, `&&`, `||`, or shell scripting grammar.
- Log analysis accepts an explicit file path; access to protected RHEL logs may require appropriate permissions.
- Service monitoring is process-based and does not parse all systemd unit states.
- No worker threads are created because the required features do not need concurrent in-process workers. Helgrind can still be run against the program.
- Google Test is a C++ framework. The core application and included tests are C. A Google Test adapter can be added by a team that specifically requires that framework; this project does not force C++ into the application.
- MISRA C:2012 compliance is a review and tool-qualification activity. POSIX APIs and dynamic allocation are subject to project-specific deviations; this code should not be represented as formally certified MISRA-compliant without a documented compliance audit.
- Coverage thresholds (>90% line, >85% branch, >95% function) are targets, not claimed results. Measure them on the final target environment.

## Safety
Do not run destructive commands as root. IMC executes external commands with the privileges of the current user.
