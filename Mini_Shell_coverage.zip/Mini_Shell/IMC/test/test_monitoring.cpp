#include "test_support.h"

TEST(Monitoring, UnknownCommandIsNotHandled) {
    shell_context_t c{};
    bool h = true;
    char n[] = "not_monitoring";
    command_stage_t s{};
    s.argv[0] = n;
    s.argc = 1;
    EXPECT_EQ(monitoring_execute(&c, &s, &h), 0);
    EXPECT_FALSE(h);
    EXPECT_EQ(monitoring_execute(&c, nullptr, &h), 0);
    EXPECT_EQ(monitoring_execute(&c, &s, nullptr), 0);
}

TEST(Monitoring, HealthcheckAndSystemSummary) {
    shell_context_t c{};
    bool h = false;
    char health[] = "healthcheck";
    command_stage_t s{};
    s.argv[0] = health;
    s.argc = 1;
    testing::internal::CaptureStdout();
    EXPECT_EQ(monitoring_execute(&c, &s, &h), 0);
    (void)testing::internal::GetCapturedStdout();
    EXPECT_TRUE(h);

    char summary[] = "system-summary";
    s.argv[0] = summary;
    h = false;
    testing::internal::CaptureStdout();
    EXPECT_EQ(monitoring_execute(&c, &s, &h), 0);
    (void)testing::internal::GetCapturedStdout();
    EXPECT_TRUE(h);
}

TEST(Monitoring, ServiceStatusExecution) {
    shell_context_t c{};
    bool h = false;
    char cmd[] = "service-status";
    command_stage_t s{};
    s.argv[0] = cmd;
    s.argc = 1;
    testing::internal::CaptureStdout();
    EXPECT_EQ(monitoring_execute(&c, &s, &h), 0);
    auto out = testing::internal::GetCapturedStdout();
    EXPECT_TRUE(h);
    EXPECT_NE(out.find("PID"), std::string::npos);

    char filter[] = "system";
    s.argv[1] = filter;
    s.argc = 2;
    h = false;
    testing::internal::CaptureStdout();
    EXPECT_EQ(monitoring_execute(&c, &s, &h), 0);
    (void)testing::internal::GetCapturedStdout();
    EXPECT_TRUE(h);
}

TEST(Monitoring, LogSearchAndSummary) {
    shell_context_t c{};
    bool h = false;
    auto f = temp_name("monitor.log");
    {
        std::ofstream o(f);
        o << "INFO startup\nERROR disk full\nDEBUG ok\n";
    }
    char cmd[] = "log-search", key[] = "ERROR";
    command_stage_t s{};
    s.argv[0] = cmd;
    s.argv[1] = key;
    s.argv[2] = const_cast<char*>(f.c_str());
    s.argc = 3;
    testing::internal::CaptureStdout();
    EXPECT_EQ(monitoring_execute(&c, &s, &h), 0);
    auto out = testing::internal::GetCapturedStdout();
    EXPECT_TRUE(h);
    EXPECT_NE(out.find("Matches: 1"), std::string::npos);

    char sum[] = "log-summary";
    s = {};
    s.argv[0] = sum;
    s.argv[1] = const_cast<char*>(f.c_str());
    s.argc = 2;
    h = false;
    testing::internal::CaptureStdout();
    EXPECT_EQ(monitoring_execute(&c, &s, &h), 0);
    out = testing::internal::GetCapturedStdout();
    EXPECT_TRUE(h);
    EXPECT_NE(out.find("Log lines: 3"), std::string::npos);
    std::remove(f.c_str());
}

TEST(Monitoring, CleanupAndAuditReport) {
    shell_context_t c{};
    config_defaults(&c.config);
    bool h = false;
    char cln[] = "cleanup";
    command_stage_t s{};
    s.argv[0] = cln;
    s.argc = 1;
    testing::internal::CaptureStdout();
    EXPECT_EQ(monitoring_execute(&c, &s, &h), 0);
    (void)testing::internal::GetCapturedStdout();
    EXPECT_TRUE(h);

    char audit[] = "audit-report";
    s.argv[0] = audit;
    h = false;
    testing::internal::CaptureStdout();
    EXPECT_EQ(monitoring_execute(&c, &s, &h), 0);
    (void)testing::internal::GetCapturedStdout();
    EXPECT_TRUE(h);
}

TEST(Monitoring, InvalidArgumentsAreHandled) {
    shell_context_t c{};
    bool h = false;
    char n[] = "log-search";
    command_stage_t s{};
    s.argv[0] = n;
    s.argc = 1;
    EXPECT_EQ(monitoring_execute(&c, &s, &h), 2);
    EXPECT_TRUE(h);
}
