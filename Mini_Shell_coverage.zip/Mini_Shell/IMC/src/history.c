#include "imc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void history_add(const imc_config_t *config, const char *command)
{
    FILE *file;
    time_t now;
    struct tm *time_info;
    char timestamp[32];

    if ((config == NULL) || (command == NULL) || (command[0] == '\0')) {
        return;
    }
    file = fopen(config->history_path, "a");
    if (file == NULL) {
        logger_log(LOG_WARNING, "Cannot open history file %s", config->history_path);
        return;
    }
    now = time(NULL);
    time_info = localtime(&now);
    if (time_info != NULL) {
        (void)strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", time_info);
    } else {
        (void)snprintf(timestamp, sizeof(timestamp), "unknown-time");
    }
    (void)fprintf(file, "%s,%s\n", timestamp, command);
    (void)fclose(file);
}

void history_show(const imc_config_t *config, size_t limit)
{
    FILE *file;
    char **lines;
    char buffer[MAX_LOG_LINE];
    size_t count = 0U;
    size_t effective_limit;
    size_t i;

    if (config == NULL) {
        return;
    }
    effective_limit = (limit == 0U) ? config->history_size : limit;
    lines = (char **)calloc(effective_limit, sizeof(char *));
    if (lines == NULL) {
        (void)fprintf(stderr, "history: memory allocation failed\n");
        return;
    }
    file = fopen(config->history_path, "r");
    if (file == NULL) {
        (void)printf("No command history yet.\n");
        free(lines);
        return;
    }
    while (fgets(buffer, (int)sizeof(buffer), file) != NULL) {
        char *copy = strdup(buffer);
        if (copy == NULL) {
            break;
        }
        if (count < effective_limit) {
            lines[count] = copy;
            count++;
        } else {
            free(lines[0]);
            for (i = 1U; i < effective_limit; i++) {
                lines[i - 1U] = lines[i];
            }
            lines[effective_limit - 1U] = copy;
        }
    }
    (void)fclose(file);
    for (i = 0U; i < count; i++) {
        (void)printf("%zu  %s", i + 1U, lines[i]);
        free(lines[i]);
    }
    free(lines);
}
