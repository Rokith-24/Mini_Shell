#include "test_support.h"

TEST(Builtin, ParentOnlyClassification) {
    EXPECT_TRUE(builtin_is_parent_only("cd"));
    EXPECT_TRUE(builtin_is_parent_only("exit"));
    EXPECT_TRUE(builtin_is_parent_only("quit"));
    EXPECT_TRUE(builtin_is_parent_only("fg"));
    EXPECT_TRUE(builtin_is_parent_only("bg"));
    EXPECT_TRUE(builtin_is_parent_only("kill-job"));
    EXPECT_FALSE(builtin_is_parent_only("ls"));
    EXPECT_FALSE(builtin_is_parent_only(nullptr));
}

TEST(Builtin, HelpPwdAndCd) {
    shell_context_t c{};
    bool h = false;
    command_stage_t s{};
    char help[] = "help";
    s.argv[0] = help;
    s.argc = 1;

    testing::internal::CaptureStdout();
    EXPECT_EQ(builtin_execute(&c, &s, &h), 0);
    (void)testing::internal::GetCapturedStdout();
    EXPECT_TRUE(h);

    char pwd[] = "pwd";
    s.argv[0] = pwd;
    h = false;
    testing::internal::CaptureStdout();
    EXPECT_EQ(builtin_execute(&c, &s, &h), 0);
    (void)testing::internal::GetCapturedStdout();
    EXPECT_TRUE(h);

    char cd[] = "cd";
    char dir[] = "/tmp";
    s.argv[0] = cd;
    s.argv[1] = dir;
    s.argc = 2;
    h = false;
    EXPECT_EQ(builtin_execute(&c, &s, &h), 0);
    EXPECT_TRUE(h);

    char bad_dir[] = "/nonexistent_dir_123456";
    s.argv[1] = bad_dir;
    h = false;
    EXPECT_EQ(builtin_execute(&c, &s, &h), 1);
    EXPECT_TRUE(h);

    s.argc = 1;
    h = false;
    (void)builtin_execute(&c, &s, &h);
    EXPECT_TRUE(h);
}

TEST(Builtin, ExitCommandSetsStatus) {
    shell_context_t c{};
    bool h = false;
    command_stage_t s{};
    char ex[] = "exit";
    char code[] = "42";
    s.argv[0] = ex;
    s.argv[1] = code;
    s.argc = 2;

    EXPECT_EQ(builtin_execute(&c, &s, &h), 42);
    EXPECT_TRUE(h);
    EXPECT_TRUE(c.should_exit);
    EXPECT_EQ(c.last_status, 42);

    char quit[] = "quit";
    s.argv[0] = quit;
    s.argc = 1;
    h = false;
    EXPECT_EQ(builtin_execute(&c, &s, &h), 0);
    EXPECT_TRUE(h);
}

TEST(Builtin, JobControlCommands) {
    shell_context_t c{};
    c.next_job_id = 1;
    config_defaults(&c.config);

    // Fork a child process that sets its pgid so kill(-pgid) works reliably
    pid_t pid = fork();
    if (pid == 0) {
        setpgid(0, 0);
        close(0);
        close(1);
        close(2);
        while (1) {
            pause();
        }
        _exit(0);
    }
    setpgid(pid, pid);
    jobs_add(&c, pid, "mock_job", JOB_STOPPED);

    bool h = false;
    command_stage_t s{};
    char bg[] = "bg";
    char id_str[16];
    (void)snprintf(id_str, sizeof(id_str), "%u", c.jobs->job_id);
    s.argv[0] = bg;
    s.argv[1] = id_str;
    s.argc = 2;

    testing::internal::CaptureStdout();
    EXPECT_EQ(builtin_execute(&c, &s, &h), 0);
    (void)testing::internal::GetCapturedStdout();
    EXPECT_TRUE(h);

    // Test missing job ID
    s.argc = 1;
    h = false;
    EXPECT_EQ(builtin_execute(&c, &s, &h), 2);
    EXPECT_TRUE(h);

    // Test nonexistent job ID
    char bad_id[] = "999";
    s.argv[1] = bad_id;
    s.argc = 2;
    h = false;
    EXPECT_EQ(builtin_execute(&c, &s, &h), 1);
    EXPECT_TRUE(h);

    // Cleanup background process
    kill(pid, SIGKILL);
    int st = 0;
    waitpid(pid, &st, 0);
    jobs_cleanup(&c);
}

TEST(Builtin, NullGuards) {
    bool h = false;
    command_stage_t s{};
    char n[] = "cd";
    s.argv[0] = n;
    s.argc = 1;
    EXPECT_EQ(builtin_execute(nullptr, &s, &h), 0);
    shell_context_t c{};
    EXPECT_EQ(builtin_execute(&c, nullptr, &h), 0);
    EXPECT_EQ(builtin_execute(&c, &s, nullptr), 0);
    s.argc = 0;
    EXPECT_EQ(builtin_execute(&c, &s, &h), 0);
}
