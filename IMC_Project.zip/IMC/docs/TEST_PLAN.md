# Test Plan

## Included automated tests
- Parser test for quoted arguments and a two-stage pipeline.
- Build smoke test.
- End-to-end pipeline smoke test.

## Manual acceptance checklist
- [ ] Prompt appears in interactive mode.
- [ ] `pwd`, `cd`, `help`, `history`, `exit` work.
- [ ] External commands are found through `PATH`.
- [ ] Foreground commands wait and return an exit status.
- [ ] Background commands return immediately and appear in `jobs`.
- [ ] `fg`, `bg`, and `kill-job` act on tracked process groups.
- [ ] `command | command` connects standard output to standard input.
- [ ] `<`, `>`, and `>>` redirections work.
- [ ] `$HOME` and `${PATH}` expansion work.
- [ ] `;` runs multiple commands in sequence.
- [ ] Audit and history files are written.
- [ ] `healthcheck`, `service-status`, `log-search`, `log-summary`, `audit-report` run.
- [ ] Ctrl+C does not terminate the interactive shell.
- [ ] Valgrind reports no definitely-lost allocations during tested paths.

## Environment-dependent checks
Valgrind, Helgrind, Cppcheck, gcov, lcov and genhtml must be installed on the target machine. RHEL log files such as `/var/log/secure` may require elevated permissions.
