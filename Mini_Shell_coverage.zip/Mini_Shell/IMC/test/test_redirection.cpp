#include "test_support.h"

extern "C" void __gcov_dump(void);

TEST(Redirection, ApplyAllBranches) {
    EXPECT_EQ(redirection_apply(nullptr), IMC_ERROR);

    auto in_f = temp_name("redir_in.txt");
    auto out_f = temp_name("redir_out.txt");
    {
        std::ofstream o(in_f);
        o << "data line\n";
    }

    command_stage_t stage{};
    (void)snprintf(stage.input_file, sizeof(stage.input_file), "%s", in_f.c_str());
    (void)snprintf(stage.output_file, sizeof(stage.output_file), "%s", out_f.c_str());
    stage.append_output = true;

    // Save fds before applying redirection in current process so gcov flushes
    int saved_stdin = dup(STDIN_FILENO);
    int saved_stdout = dup(STDOUT_FILENO);

    int r = redirection_apply(&stage);
    EXPECT_EQ(r, IMC_OK);

    // Overwrite mode
    stage.append_output = false;
    r = redirection_apply(&stage);
    EXPECT_EQ(r, IMC_OK);

    // Error on input
    (void)snprintf(stage.input_file, sizeof(stage.input_file), "/nonexistent_in_file_123");
    // temporarily close stderr to mute perror
    int saved_stderr = dup(STDERR_FILENO);
    close(STDERR_FILENO);
    r = redirection_apply(&stage);
    dup2(saved_stderr, STDERR_FILENO);
    close(saved_stderr);
    EXPECT_EQ(r, IMC_ERROR);

    // Error on output
    stage.input_file[0] = '\0';
    (void)snprintf(stage.output_file, sizeof(stage.output_file), "/proc/read_only_fake_out");
    saved_stderr = dup(STDERR_FILENO);
    close(STDERR_FILENO);
    r = redirection_apply(&stage);
    dup2(saved_stderr, STDERR_FILENO);
    close(saved_stderr);
    EXPECT_EQ(r, IMC_ERROR);

    // Restore fds
    dup2(saved_stdin, STDIN_FILENO);
    close(saved_stdin);
    dup2(saved_stdout, STDOUT_FILENO);
    close(saved_stdout);

    std::remove(in_f.c_str());
    std::remove(out_f.c_str());
}
