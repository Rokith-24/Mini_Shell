#include "test_support.h"

TEST(Parser, AllTokenTypesAndExpansions) {
    setenv("IMC_TEST_ENV", "environment_value", 1);
    char s[] = "echo 'single quote' \"double $IMC_TEST_ENV\" \\ escaped $ normal_word < in > out >> app ; cat | grep &";
    parsed_line_t p{};
    char e[256]{};
    ASSERT_EQ(parse_line(s, &p, e, sizeof(e)), IMC_OK);
    EXPECT_GE(p.command_count, 1U);
    free_parsed(&p);
}

TEST(Parser, ErrorHandlingAndLimits) {
    parsed_line_t p{};
    char e[256]{};

    // Unclosed quote
    char bad_q[] = "echo \"unclosed quote";
    EXPECT_EQ(parse_line(bad_q, &p, e, sizeof(e)), IMC_PARSE_ERROR);

    // Empty pipe
    char bad_pipe[] = "echo | | grep";
    EXPECT_EQ(parse_line(bad_pipe, &p, e, sizeof(e)), IMC_PARSE_ERROR);

    // Missing redirection target
    char bad_in[] = "echo <";
    EXPECT_EQ(parse_line(bad_in, &p, e, sizeof(e)), IMC_PARSE_ERROR);

    char bad_out[] = "echo >";
    EXPECT_EQ(parse_line(bad_out, &p, e, sizeof(e)), IMC_PARSE_ERROR);

    char bad_app[] = "echo >>";
    EXPECT_EQ(parse_line(bad_app, &p, e, sizeof(e)), IMC_PARSE_ERROR);

    // Invalid & position
    char bad_amp[] = "echo & more";
    EXPECT_EQ(parse_line(bad_amp, &p, e, sizeof(e)), IMC_PARSE_ERROR);

    // Semicolon without command
    char bad_semi[] = ";";
    EXPECT_EQ(parse_line(bad_semi, &p, e, sizeof(e)), IMC_PARSE_ERROR);

    // Empty string
    char empty[] = "";
    EXPECT_EQ(parse_line(empty, &p, e, sizeof(e)), IMC_OK);

    // Null pointers
    EXPECT_EQ(parse_line(nullptr, &p, e, sizeof(e)), IMC_ERROR);
    EXPECT_EQ(parse_line(empty, nullptr, e, sizeof(e)), IMC_ERROR);

    // Free null safe
    parse_free(nullptr);
}
