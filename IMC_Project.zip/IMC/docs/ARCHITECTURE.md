# IMC Architecture

## Runtime flow

1. `main.c` creates runtime directories, loads `config/imc.conf`, starts the logger and shell.
2. `shell.c` displays the prompt, reads bounded input, stores history and dispatches parsed commands.
3. `parser.c` tokenizes words, quotes, environment expansions, pipelines, redirections, background markers and command separators.
4. `process.c` creates process groups, forks pipeline stages, connects pipes, applies redirections and waits for foreground work.
5. `builtin.c` implements stateful shell commands and delegates infrastructure commands.
6. `jobs.c` tracks background/stopped jobs and reaps exited children.
7. `history.c`, `audit.c`, `logger.c` persist command history, audit records and diagnostics.
8. `monitoring.c` reads Linux `/proc` data and provides infrastructure-oriented commands.

## Process model

The shell is a user-space process. The Linux kernel performs process creation, scheduling, memory management and executable loading. IMC uses `fork`, `execvp`, `waitpid`, process groups, `pipe`, `open` and `dup2` to provide shell behavior.

## Important implementation boundaries

- The target is Linux/POSIX (RHEL 8/9). The process model is not a native Windows implementation.
- Service status is process-oriented. It does not call systemd's private APIs; administrators can still run `systemctl` as an external command.
- `cleanup` removes only temporary report files matching `*.tmp`; it does not delete user data or system logs.
- Threaded workers are not enabled by default. The current requirements can be met by a single event loop and asynchronous child-process notifications.
- The parser is intentionally bounded by compile-time limits to avoid unbounded input and argument storage.
