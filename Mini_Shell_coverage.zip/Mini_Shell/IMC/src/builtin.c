#include "imc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <sys/wait.h>

bool builtin_is_parent_only(const char *name)
{
    bool parent_only = false;
    if (name != NULL) {
        if ((strcmp(name, "cd") == 0) || (strcmp(name, "exit") == 0) || (strcmp(name, "quit") == 0) ||
            (strcmp(name, "fg") == 0) || (strcmp(name, "bg") == 0) || (strcmp(name, "kill-job") == 0)) {
            parent_only = true;
        }
    }
    return parent_only;
}

int builtin_execute(shell_context_t *context, command_stage_t *stage, bool *handled)
{
    const char *name;
    int result = 0;

    if (handled == NULL) {
        return 0;
    }
    *handled = false;

    if ((context == NULL) || (stage == NULL) || (stage->argc == 0U)) {
        return 0;
    }
    name = stage->argv[0];

    if (strcmp(name, "cd") == 0) {
        const char *target = (stage->argc > 1U) ? stage->argv[1] : getenv("HOME");
        *handled = true;
        if ((target == NULL) || (chdir(target) != 0)) {
            (void)perror("cd");
            result = 1;
        }
    } else if (strcmp(name, "pwd") == 0) {
        char cwd[MAX_PATH_LENGTH];
        *handled = true;
        if (getcwd(cwd, sizeof(cwd)) == NULL) {
            (void)perror("pwd");
            result = 1;
        } else {
            (void)printf("%s\n", cwd);
        }
    } else if (strcmp(name, "help") == 0) {
        *handled = true;
        (void)printf("IMC built-ins:\n");
        (void)printf("  cd [DIR]  pwd  exit  help  history  jobs  fg JOB  bg JOB  kill-job JOB\n");
        (void)printf("  service-status [NAME]  log-search KEYWORD [FILE]  log-summary [FILE]\n");
        (void)printf("  healthcheck  system-summary  cleanup  audit-report\n");
        (void)printf("Shell syntax: command | command, < input, > output, >> output, command &, command ; command\n");
    } else if ((strcmp(name, "exit") == 0) || (strcmp(name, "quit") == 0)) {
        *handled = true;
        context->should_exit = true;
        if (stage->argc > 1U) {
            context->last_status = (int)strtol(stage->argv[1], NULL, 10);
            result = context->last_status;
        }
    } else if (strcmp(name, "history") == 0) {
        *handled = true;
        history_show(&context->config, (stage->argc > 1U) ? (size_t)strtoul(stage->argv[1], NULL, 10) : 0U);
    } else if (strcmp(name, "jobs") == 0) {
        *handled = true;
        jobs_reap(context);
        jobs_list(context);
    } else if ((strcmp(name, "fg") == 0) || (strcmp(name, "bg") == 0) || (strcmp(name, "kill-job") == 0)) {
        *handled = true;
        if (stage->argc < 2U) {
            (void)fprintf(stderr, "%s: job id required\n", name);
            result = 2;
        } else {
            uint32_t id = (uint32_t)strtoul(stage->argv[1], NULL, 10);
            job_t *job = jobs_find(context, id);
            if (job == NULL) {
                (void)fprintf(stderr, "%s: no such job: %u\n", name, id);
                result = 1;
            } else if (strcmp(name, "kill-job") == 0) {
                if (kill(-job->pgid, SIGTERM) != 0) {
                    (void)perror("kill-job");
                    result = 1;
                } else {
                    result = 0;
                }
            } else if (strcmp(name, "bg") == 0) {
                if (kill(-job->pgid, SIGCONT) != 0) {
                    (void)perror("bg");
                    result = 1;
                } else {
                    job->state = JOB_RUNNING;
                    (void)printf("[%u] %s &\n", job->job_id, job->command);
                    result = 0;
                }
            } else {
                /* fg */
                if ((kill(-job->pgid, SIGCONT) != 0) && (errno != ESRCH)) {
                    (void)perror("fg");
                    result = 1;
                } else {
                    int status = 0;
                    pid_t waited;
                    if (context->interactive) {
                        (void)tcsetpgrp(STDIN_FILENO, job->pgid);
                    }
                    do {
                        waited = waitpid(-job->pgid, &status, WUNTRACED);
                    } while ((waited < 0) && (errno == EINTR));

                    if (context->interactive) {
                        (void)tcsetpgrp(STDIN_FILENO, context->shell_pgid);
                    }
                    if ((waited > 0) && (WIFSTOPPED(status) != 0)) {
                        job->state = JOB_STOPPED;
                    } else {
                        jobs_remove(context, id);
                    }
                    if ((waited > 0) && (WIFEXITED(status) != 0)) {
                        result = WEXITSTATUS(status);
                    }
                }
            }
        }
    } else {
        bool monitoring_handled = false;
        result = monitoring_execute(context, stage, &monitoring_handled);
        *handled = monitoring_handled;
    }

    return result;
}
