#ifndef IMC_TEST_SUPPORT_H
#define IMC_TEST_SUPPORT_H
#include <gtest/gtest.h>
extern "C" {
#include "imc.h"
}
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <string>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

static inline std::string temp_name(const char *suffix) {
    return std::string("/tmp/imc_gtest_") + std::to_string((long)getpid()) + "_" + suffix;
}

static inline void free_parsed(parsed_line_t *p) {
    parse_free(p);
}
#endif
