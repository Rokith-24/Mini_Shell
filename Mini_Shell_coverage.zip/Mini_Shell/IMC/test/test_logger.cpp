#include "test_support.h"

TEST(Logger, InitLogAndClose) {
    auto f = temp_name("imc.log");
    logger_init(f.c_str());
    logger_log(LOG_DEBUG, "debug message %d", 1);
    logger_log(LOG_INFO, "info message %s", "ready");
    logger_log(LOG_WARNING, "warning message");
    logger_log(LOG_ERROR, "error message");
    logger_log(LOG_FATAL, "fatal message");
    logger_close();

    std::ifstream is(f);
    std::string content((std::istreambuf_iterator<char>(is)), std::istreambuf_iterator<char>());
    EXPECT_NE(content.find("DEBUG"), std::string::npos);
    EXPECT_NE(content.find("FATAL"), std::string::npos);
    std::remove(f.c_str());

    logger_init(nullptr);
    logger_log(LOG_INFO, "no file logging");
    logger_close();
}
