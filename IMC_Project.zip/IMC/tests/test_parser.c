#include "imc.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
    parsed_line_t parsed;
    char input[MAX_INPUT_LENGTH] = "printf 'hello world' | wc -c";
    char error[256];
    int result = parse_line(input, &parsed, error, sizeof(error));
    if (result != IMC_OK) {
        (void)fprintf(stderr, "Parser test failed: %s\n", error);
        return 1;
    }
    if (parsed.command_count != 1U || parsed.commands[0].stage_count != 2U ||
        parsed.commands[0].stages[0].argc != 2U ||
        strcmp(parsed.commands[0].stages[0].argv[1], "hello world") != 0) {
        (void)fprintf(stderr, "Parser structure assertion failed\n");
        return 1;
    }
    (void)printf("Parser basic pipeline/quote test passed.\n");
    /* This test process owns parser allocations. */
    free(parsed.commands[0].stages[0].argv[0]);
    free(parsed.commands[0].stages[0].argv[1]);
    free(parsed.commands[0].stages[1].argv[0]);
    free(parsed.commands[0].stages[1].argv[1]);
    return 0;
}
