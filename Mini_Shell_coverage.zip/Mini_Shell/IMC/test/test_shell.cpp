#include "test_support.h"

TEST(Shell, DirectExecutionCoverage) {
    EXPECT_EQ(shell_run(nullptr), IMC_ERROR);

    auto f = temp_name("shell_stdin.txt");
    {
        std::ofstream o(f);
        o << "\n"
          << "help\n"
          << "pwd\n"
          << "cd /tmp\n"
          << "echo covered_shell\n"
          << "jobs\n"
          << "healthcheck\n"
          << "system-summary\n"
          << "service-status\n"
          << "cleanup\n"
          << "audit-report\n"
          << "history 5\n"
          << "nonexistent_command_123 2>/dev/null\n"
          << "echo 'unclosed quote\n"
          << "exit 0\n";
    }

    FILE *orig_stdin = stdin;
    stdin = fopen(f.c_str(), "r");
    ASSERT_NE(stdin, nullptr);

    testing::internal::CaptureStdout();
    testing::internal::CaptureStderr();

    shell_context_t context{};
    (void)memset(&context, 0, sizeof(context));
    context.next_job_id = 1U;
    config_defaults(&context.config);
    int res = shell_run(&context);

    (void)testing::internal::GetCapturedStdout();
    (void)testing::internal::GetCapturedStderr();

    (void)fclose(stdin);
    stdin = orig_stdin;
    std::remove(f.c_str());

    EXPECT_EQ(res, 0);
}
