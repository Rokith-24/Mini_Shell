#include "test_support.h"

TEST(Jobs, AddFindRemoveListAndCleanup) {
    shell_context_t c{};
    c.next_job_id = 1;
    jobs_add(&c, 12345, "sleep 1", JOB_RUNNING);
    ASSERT_NE(c.jobs, nullptr);
    EXPECT_EQ(c.jobs->job_id, 1U);
    EXPECT_EQ(jobs_find(&c, 1)->pgid, 12345);
    EXPECT_EQ(jobs_find(&c, 99), nullptr);

    testing::internal::CaptureStdout();
    jobs_list(&c);
    auto out = testing::internal::GetCapturedStdout();
    EXPECT_NE(out.find("sleep 1"), std::string::npos);

    // List with different states
    c.jobs->state = JOB_STOPPED;
    testing::internal::CaptureStdout();
    jobs_list(&c);
    out = testing::internal::GetCapturedStdout();
    EXPECT_NE(out.find("Stopped"), std::string::npos);

    c.jobs->state = JOB_DONE;
    testing::internal::CaptureStdout();
    jobs_list(&c);
    out = testing::internal::GetCapturedStdout();
    EXPECT_NE(out.find("Done"), std::string::npos);

    jobs_remove(&c, 1);
    EXPECT_EQ(c.jobs, nullptr);

    // Multiple adds to test traversal and removal of middle/tail
    jobs_add(&c, 2001, "cmd 1", JOB_RUNNING);
    jobs_add(&c, 2002, "cmd 2", JOB_RUNNING);
    jobs_add(&c, 2003, "cmd 3", JOB_RUNNING);
    jobs_remove(&c, 2); // remove middle
    jobs_cleanup(&c);
    EXPECT_EQ(c.jobs, nullptr);
}

TEST(Jobs, ReapOperations) {
    shell_context_t c{};
    c.next_job_id = 1;

    // Start child and wait for it in reap
    pid_t pid = fork();
    if (pid == 0) {
        _exit(0);
    }
    jobs_add(&c, pid, "quick_exit", JOB_RUNNING);
    int st;
    waitpid(pid, &st, 0); // wait first or let reap do it
    jobs_reap(&c);
    jobs_cleanup(&c);
}

TEST(Jobs, NullAndEmptyOperationsAreSafe) {
    EXPECT_EQ(jobs_find(nullptr, 1), nullptr);
    jobs_add(nullptr, 1, "x", JOB_RUNNING);
    jobs_remove(nullptr, 1);
    jobs_list(nullptr);
    jobs_reap(nullptr);
    jobs_cleanup(nullptr);

    shell_context_t c{};
    jobs_list(&c);
    jobs_reap(&c);
    jobs_cleanup(&c);
}
