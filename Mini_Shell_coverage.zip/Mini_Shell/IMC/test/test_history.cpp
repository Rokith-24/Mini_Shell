#include "test_support.h"

TEST(History, AddAndShowOperations) {
    auto f = temp_name("history.txt");
    imc_config_t config{};
    config_defaults(&config);
    (void)snprintf(config.history_path, sizeof(config.history_path), "%s", f.c_str());

    history_add(&config, "ls -l");
    history_add(&config, "pwd");

    testing::internal::CaptureStdout();
    history_show(&config, 10);
    auto out = testing::internal::GetCapturedStdout();
    EXPECT_NE(out.find("ls -l"), std::string::npos);
    EXPECT_NE(out.find("pwd"), std::string::npos);

    std::remove(f.c_str());
}

TEST(History, NullAndMissingHandling) {
    history_add(nullptr, "cmd");
    imc_config_t config{};
    config_defaults(&config);
    history_add(&config, nullptr);
    history_add(&config, "");

    (void)snprintf(config.history_path, sizeof(config.history_path), "/tmp/nonexistent_history_file_123");
    testing::internal::CaptureStdout();
    history_show(&config, 5);
    auto out = testing::internal::GetCapturedStdout();
    EXPECT_NE(out.find("No command history yet"), std::string::npos);
    history_show(nullptr, 5);
}
