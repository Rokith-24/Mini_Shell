#include "test_support.h"

TEST(Integration, BinaryStartsAndAcceptsExit) {
    int fds[2];
    ASSERT_EQ(pipe(fds), 0);
    const char cmd[] = "help\nexit\n";
    ASSERT_EQ(write(fds[1], cmd, sizeof(cmd) - 1), (ssize_t)(sizeof(cmd) - 1));
    close(fds[1]);

    pid_t pid = fork();
    ASSERT_GE(pid, 0);
    if (pid == 0) {
        dup2(fds[0], STDIN_FILENO);
        close(fds[0]);
        shell_context_t context{};
        (void)memset(&context, 0, sizeof(context));
        context.next_job_id = 1U;
        config_defaults(&context.config);
        _exit(shell_run(&context));
    }
    close(fds[0]);
    int status = 0;
    waitpid(pid, &status, 0);
    EXPECT_TRUE(WIFEXITED(status));
    EXPECT_EQ(WEXITSTATUS(status), 0);
}

TEST(Integration, PipelineAndRedirectionExecution) {
    int fds[2];
    ASSERT_EQ(pipe(fds), 0);
    const char cmd[] = "echo test_pipe | grep test_pipe\nexit\n";
    ASSERT_EQ(write(fds[1], cmd, sizeof(cmd) - 1), (ssize_t)(sizeof(cmd) - 1));
    close(fds[1]);

    pid_t pid = fork();
    ASSERT_GE(pid, 0);
    if (pid == 0) {
        dup2(fds[0], STDIN_FILENO);
        close(fds[0]);
        shell_context_t context{};
        (void)memset(&context, 0, sizeof(context));
        context.next_job_id = 1U;
        config_defaults(&context.config);
        _exit(shell_run(&context));
    }
    close(fds[0]);
    int status = 0;
    waitpid(pid, &status, 0);
    EXPECT_TRUE(WIFEXITED(status));
    EXPECT_EQ(WEXITSTATUS(status), 0);
}
